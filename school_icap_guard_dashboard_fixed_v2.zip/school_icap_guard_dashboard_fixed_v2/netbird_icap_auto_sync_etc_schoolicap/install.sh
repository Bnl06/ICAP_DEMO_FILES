#!/usr/bin/env bash
set -euo pipefail

# NetBird -> School ICAP Guard sync installer
# Correct setup for this environment:
# - ICAP itself is NOT changed.
# - ICAP already uses /etc/school-icap-guard.
# - NetBird sync also writes to /etc/school-icap-guard.
# - NetBird sync runs as schoolicap to avoid root-owned JSON conflicts.

INSTALL_DIR="${INSTALL_DIR:-/opt/school-icap-guard}"
CONFIG_DIR="${ICAP_CONFIG_DIR:-/etc/school-icap-guard}"
ENV_FILE="${ENV_FILE:-/etc/school-icap-guard-netbird.env}"
ICAP_SERVICE="${ICAP_SERVICE:-school-icap-guard.service}"
SYNC_USER="${SYNC_USER:-schoolicap}"
SYNC_GROUP="${SYNC_GROUP:-schoolicap}"
NETBIRD_API_DEFAULT="${NETBIRD_API:-https://netbird.secure1e.org}"
AUTO_CREATE_POLICIES="${ICAP_AUTO_CREATE_POLICIES:-1}"
POLICY_TEMPLATE="${ICAP_POLICY_TEMPLATE:-student}"
SYNC_INTERVAL_SECONDS="${SYNC_INTERVAL_SECONDS:-60}"
TOKEN="${NETBIRD_TOKEN:-nbp_LzQs0EKb1pWQqdNPF46Ccb4Rx8w1P62KyaLT}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "ERROR: run as root: sudo ./install.sh"
  exit 1
fi

if [[ ! -d "$INSTALL_DIR" ]]; then
  echo "ERROR: $INSTALL_DIR bestaat niet. Installeer eerst School ICAP Guard of zet INSTALL_DIR=/pad/naar/installatie."
  exit 1
fi

if ! id "$SYNC_USER" >/dev/null 2>&1; then
  echo "ERROR: user '$SYNC_USER' bestaat niet. Maak eerst de schoolicap user aan of zet SYNC_USER=..."
  exit 1
fi

if [[ -z "$TOKEN" ]]; then
  echo "ERROR: token is leeg."
  exit 1
fi

mkdir -p "$CONFIG_DIR"

# Zorg dat de sync-user de config kan lezen en schrijven.
chown -R "$SYNC_USER:$SYNC_GROUP" "$CONFIG_DIR"
find "$CONFIG_DIR" -type d -exec chmod 750 {} \;
find "$CONFIG_DIR" -type f -exec chmod 640 {} \;

SCRIPT_SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/sync_netbird_users.py"
install -o root -g root -m 0755 "$SCRIPT_SOURCE" "$INSTALL_DIR/sync_netbird_users.py"

cat > "$ENV_FILE" <<EOFENV
NETBIRD_API=$NETBIRD_API_DEFAULT
NETBIRD_TOKEN=$TOKEN
ICAP_CONFIG_DIR=$CONFIG_DIR
ICAP_SERVICE=$ICAP_SERVICE
ICAP_AUTO_CREATE_POLICIES=$AUTO_CREATE_POLICIES
ICAP_POLICY_TEMPLATE=$POLICY_TEMPLATE
EOFENV

# De service draait als schoolicap, dus de env-file moet door die groep leesbaar zijn.
chown root:"$SYNC_GROUP" "$ENV_FILE"
chmod 640 "$ENV_FILE"

cat > /etc/systemd/system/netbird-users-sync.service <<EOFUNIT
[Unit]
Description=Sync NetBird users, peers and groups to School ICAP Guard
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=$SYNC_USER
Group=$SYNC_GROUP
EnvironmentFile=$ENV_FILE
Environment=NO_PROXY=netbird.secure1e.org,204.168.216.41,127.0.0.1,localhost,192.168.50.0/24
Environment=no_proxy=netbird.secure1e.org,204.168.216.41,127.0.0.1,localhost,192.168.50.0/24
Environment=HTTP_PROXY=
Environment=HTTPS_PROXY=
Environment=http_proxy=
Environment=https_proxy=
ExecStart=/usr/bin/python3 $INSTALL_DIR/sync_netbird_users.py
# + laat alleen deze post-actions als root draaien, terwijl de sync zelf als schoolicap draait.
ExecStartPost=+/bin/chown -R $SYNC_USER:$SYNC_GROUP $CONFIG_DIR
ExecStartPost=+/bin/systemctl restart $ICAP_SERVICE
EOFUNIT

cat > /etc/systemd/system/netbird-users-sync.timer <<EOFUNIT
[Unit]
Description=Run NetBird users sync periodically

[Timer]
OnBootSec=30
OnUnitActiveSec=$SYNC_INTERVAL_SECONDS
Unit=netbird-users-sync.service

[Install]
WantedBy=timers.target
EOFUNIT

systemctl daemon-reload
systemctl enable --now netbird-users-sync.timer

echo "INFO: eerste sync wordt nu uitgevoerd..."
systemctl start netbird-users-sync.service

echo
systemctl status netbird-users-sync.timer --no-pager || true

echo
cat <<EOFMSG
KLAAR.

Belangrijke checks:
  sudo journalctl -u netbird-users-sync.service -n 100 --no-pager
  sudo jq '.ip_map' $CONFIG_DIR/users.json
  sudo jq '.policies | keys' $CONFIG_DIR/config.json
  sudo systemctl status $ICAP_SERVICE --no-pager
  sudo ss -lntp | grep 13440

Deze installer wijzigt de ICAP service-config NIET.
Hij zorgt alleen dat NetBird sync correct naar $CONFIG_DIR schrijft en als $SYNC_USER draait.
EOFMSG

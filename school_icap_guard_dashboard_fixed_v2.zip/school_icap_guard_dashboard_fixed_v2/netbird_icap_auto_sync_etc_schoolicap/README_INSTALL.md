# NetBird → School ICAP Guard automatische sync

Deze zip is aangepast voor jouw huidige setup:

```text
ICAP config directory: /etc/school-icap-guard
NetBird API:           https://netbird.secure1e.org
NetBird sync user:     schoolicap
ICAP service:          school-icap-guard.service
```

De ICAP service zelf wordt niet aangepast. De installer maakt alleen de NetBird sync correct zodat die naar `/etc/school-icap-guard` schrijft en geen root-owned JSON-conflict veroorzaakt.

## Wat doet dit?

```text
NetBird users/peers/groups → /etc/school-icap-guard/users.json
NetBird groepen            → /etc/school-icap-guard/config.json policies
```

Daarna kan School ICAP Guard via `ip_map` bepalen:

```text
100.64.x.x → user e-mail → groepen → ICAP policy
```

## Installatie

Upload de zip naar je Ubuntu ICAP server en voer uit:

```bash
unzip netbird_icap_auto_sync_etc_schoolicap.zip -d /tmp/netbird_icap_auto_sync
cd /tmp/netbird_icap_auto_sync
sudo ./install.sh
```

De installer gebruikt standaard:

```text
NETBIRD_API=https://netbird.secure1e.org
ICAP_CONFIG_DIR=/etc/school-icap-guard
SYNC_USER=schoolicap
SYNC_GROUP=schoolicap
```

De token is al ingevuld in de scripts/env-output van deze aangepaste zip.

## Wat wordt geïnstalleerd?

```text
/opt/school-icap-guard/sync_netbird_users.py
/etc/school-icap-guard-netbird.env
/etc/systemd/system/netbird-users-sync.service
/etc/systemd/system/netbird-users-sync.timer
```

De timer draait standaard elke 60 seconden.

## Belangrijk: rechten

De installer zet:

```bash
chown -R schoolicap:schoolicap /etc/school-icap-guard
chmod 750 directories
chmod 640 files
chown root:schoolicap /etc/school-icap-guard-netbird.env
chmod 640 /etc/school-icap-guard-netbird.env
```

Daardoor kunnen zowel ICAP Guard als de NetBird sync dezelfde config-map gebruiken.

## Checks

```bash
sudo systemctl status netbird-users-sync.timer --no-pager
sudo journalctl -u netbird-users-sync.service -n 100 --no-pager
sudo jq '.ip_map' /etc/school-icap-guard/users.json
sudo jq '.policies | keys' /etc/school-icap-guard/config.json
sudo systemctl status school-icap-guard.service --no-pager
sudo ss -lntp | grep 13440
```

## Dashboard

Open:

```text
http://192.168.50.12:8088/edit?path=users.json
http://192.168.50.12:8088/edit?path=config.json
```

## OPNsense Squid GUI

Je Squid custom options moeten minstens dit bevatten:

```conf
icap_enable on
icap_preview_enable on
icap_preview_size 4096
icap_send_client_ip on
icap_send_client_username on
icap_service school_req reqmod_precache bypass=0 icap://192.168.50.12:13440/reqmod
adaptation_access school_req allow all
icap_service school_resp respmod_precache bypass=0 icap://192.168.50.12:13440/respmod
adaptation_access school_resp allow all
```

Zonder `icap_send_client_ip on` kan ICAP niet automatisch IP → user → groep matchen.

## Uninstall

```bash
sudo ./uninstall.sh
```

Dit verwijdert alleen de systemd timer/service. Het verwijdert niet automatisch je tokenfile of sync script.

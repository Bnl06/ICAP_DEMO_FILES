#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "ERROR: run as root: sudo ./uninstall.sh"
  exit 1
fi

systemctl disable --now netbird-users-sync.timer 2>/dev/null || true
rm -f /etc/systemd/system/netbird-users-sync.timer
rm -f /etc/systemd/system/netbird-users-sync.service
systemctl daemon-reload

echo "Removed systemd timer/service."
echo "Niet verwijderd: /etc/school-icap-guard-netbird.env en /opt/school-icap-guard/sync_netbird_users.py"

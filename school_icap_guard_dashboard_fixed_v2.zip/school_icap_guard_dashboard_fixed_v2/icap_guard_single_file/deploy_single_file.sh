#!/usr/bin/env bash
set -euo pipefail

# Deploy één-file versie van School ICAP Guard.
# Gebruik:
#   chmod +x deploy_single_file.sh
#   ./deploy_single_file.sh

DEST_DIR="/opt/school-icap-guard"
SERVICE_NAME="school-icap-guard"
SRC_FILE="school_icap_guard.py"

echo "==> Doelmap maken: $DEST_DIR"
sudo mkdir -p "$DEST_DIR"

echo "==> ICAP hoofdfile installeren"
sudo install -o root -g root -m 0755 "$SRC_FILE" "$DEST_DIR/school_icap_guard.py"

echo "==> Syntax check"
python3 -m py_compile "$DEST_DIR/school_icap_guard.py"

echo "==> Config initialiseren indien nog niet aanwezig"
if [ ! -f "$DEST_DIR/config/config.json" ]; then
  cd "$DEST_DIR"
  sudo python3 "$DEST_DIR/school_icap_guard.py" --init
else
  echo "Config bestaat al, --init wordt overgeslagen."
  echo "Nieuwe default NL/EN phraselists worden pas aangemaakt als je config/phrases verwijdert of manueel aanvult."
fi

echo "==> Rechten herstellen"
sudo chown -R root:root "$DEST_DIR"
sudo chmod 0755 "$DEST_DIR"
sudo chmod 0755 "$DEST_DIR/school_icap_guard.py"

echo "==> systemd herladen en service herstarten"
sudo systemctl daemon-reload
sudo systemctl restart "$SERVICE_NAME"

echo "==> Status"
sudo systemctl --no-pager -l status "$SERVICE_NAME"

#!/usr/bin/env python3
"""Disable old default phrase lists and starter groups safely.

Usage:
  sudo python3 disable_default_phrases_and_groups.py --config-dir /etc/school-icap-guard

What it does:
- creates timestamped backups of config.json and users.json
- sets features.weighted_phrases_enabled=false
- clears phrase_thresholds and phrase_total_threshold from all policies
- removes starter policies student/teacher when present
- removes starter users teacher@example.org/student@example.org when present
- removes old student/teacher group restrictions from starter DLP rules
- renames existing .weightedphraselist/.phraselist files to *.disabled
  instead of deleting them, so categories/folders remain and files can be restored.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Any

PHRASE_SUFFIXES = (".weightedphraselist", ".phraselist")
STARTER_GROUPS = {"student", "teacher"}
STARTER_USERS = {"student@example.org", "teacher@example.org"}
STARTER_IPS = {"100.64.10.10", "100.64.10.20"}


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def backup(path: Path) -> Path | None:
    if not path.exists():
        return None
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_path = path.with_name(f"{path.name}.{stamp}.bak")
    backup_path.write_bytes(path.read_bytes())
    return backup_path


def disable_config(config_path: Path, remove_starter_groups: bool) -> list[str]:
    changed: list[str] = []
    config = read_json(config_path)
    if not config:
        return changed
    config.setdefault("features", {})["weighted_phrases_enabled"] = False
    changed.append("weighted_phrases_enabled=false")

    policies = [config.setdefault("common_policy", {})]
    policy_map = config.setdefault("policies", {})
    policies.extend(policy_map.values())
    for policy in policies:
        if policy.get("phrase_thresholds"):
            changed.append("phrase_thresholds cleared")
        policy["phrase_thresholds"] = {}
        if "phrase_total_threshold" in policy:
            policy.pop("phrase_total_threshold", None)
            changed.append("phrase_total_threshold removed")

    if remove_starter_groups:
        for group in sorted(STARTER_GROUPS):
            if group in policy_map:
                policy_map.pop(group, None)
                changed.append(f"removed policy group {group}")

    write_json(config_path, config)
    return changed


def disable_users(users_path: Path, remove_starter_groups: bool) -> list[str]:
    changed: list[str] = []
    users = read_json(users_path)
    if not users or not remove_starter_groups:
        return changed
    user_map = users.setdefault("users", {})
    ip_map = users.setdefault("ip_map", {})
    for user in sorted(STARTER_USERS):
        if user in user_map:
            user_map.pop(user, None)
            changed.append(f"removed starter user {user}")
    for ip in sorted(STARTER_IPS):
        if ip in ip_map:
            ip_map.pop(ip, None)
            changed.append(f"removed starter ip {ip}")
    write_json(users_path, users)
    return changed




def update_dlp_rules(dlp_path: Path) -> list[str]:
    changed: list[str] = []
    dlp = read_json(dlp_path)
    if not dlp:
        return changed
    for rule in dlp.get("rules", []):
        groups = {str(group).lower() for group in rule.get("groups", [])}
        if groups and groups.issubset(STARTER_GROUPS):
            rule.pop("groups", None)
            changed.append(f"removed starter group restriction from DLP rule {rule.get('name', 'unknown')}")
    if changed:
        write_json(dlp_path, dlp)
    return changed

def disable_phrase_files(phrase_root: Path) -> list[str]:
    changed: list[str] = []
    if not phrase_root.exists():
        return changed
    for path in sorted(phrase_root.rglob("*")):
        if not path.is_file():
            continue
        if path.name.endswith(".disabled"):
            continue
        if not any(path.name.endswith(suffix) for suffix in PHRASE_SUFFIXES):
            continue
        target = path.with_name(path.name + ".disabled")
        counter = 1
        while target.exists():
            target = path.with_name(path.name + f".{counter}.disabled")
            counter += 1
        path.rename(target)
        changed.append(f"disabled {path.relative_to(phrase_root)}")
    return changed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config-dir", default="/etc/school-icap-guard", help="Directory containing config.json/users.json/phrases")
    parser.add_argument("--keep-starter-groups", action="store_true", help="Do not remove old student/teacher starter policies/users")
    args = parser.parse_args()

    config_dir = Path(args.config_dir)
    config_path = config_dir / "config.json"
    users_path = config_dir / "users.json"
    dlp_path = config_dir / "dlp_rules.json"
    phrase_root = config_dir / "phrases"

    for path in (config_path, users_path, dlp_path):
        b = backup(path)
        if b:
            print(f"Backup: {b}")

    changes = []
    changes.extend(disable_config(config_path, remove_starter_groups=not args.keep_starter_groups))
    changes.extend(disable_users(users_path, remove_starter_groups=not args.keep_starter_groups))
    changes.extend(update_dlp_rules(dlp_path))
    changes.extend(disable_phrase_files(phrase_root))

    if changes:
        print("Aangepast:")
        for item in changes:
            print(f"- {item}")
    else:
        print("Geen wijzigingen nodig.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

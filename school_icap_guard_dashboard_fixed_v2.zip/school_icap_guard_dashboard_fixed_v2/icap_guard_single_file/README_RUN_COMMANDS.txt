School ICAP Guard - één bestand
================================

Installeren / deployen:

  unzip icap_guard_single_file.zip
  cd icap_guard_single_file
  chmod +x deploy_single_file.sh
  ./deploy_single_file.sh

Handmatig testen zonder systemd:

  sudo mkdir -p /opt/school-icap-guard
  sudo install -o root -g root -m 0755 school_icap_guard.py /opt/school-icap-guard/school_icap_guard.py
  cd /opt/school-icap-guard
  sudo python3 school_icap_guard.py --init
  sudo python3 school_icap_guard.py --check
  sudo python3 school_icap_guard.py --serve

Bestaande service herstarten:

  sudo systemctl restart school-icap-guard
  sudo systemctl status school-icap-guard
  sudo journalctl -u school-icap-guard -f

Standaard poorten:

  ICAP:      0.0.0.0:13440
  Dashboard: 127.0.0.1:8088

Squid ICAP voorbeeld:

  icap_enable on
  icap_preview_enable on
  icap_preview_size 4096
  icap_send_client_ip on
  icap_send_client_username on

  icap_service school_req reqmod_precache bypass=0 icap://192.168.50.12:13440/reqmod
  adaptation_access school_req allow all

  icap_service school_resp respmod_precache bypass=0 icap://192.168.50.12:13440/respmod
  adaptation_access school_resp allow all

Belangrijk:
- Dit is opnieuw één file: school_icap_guard.py.
- Bij --init maakt hij config/phrases/<categorie>/english.weightedphraselist en dutch.weightedphraselist aan voor alle categorieën.
- Bestaande phrase files worden niet overschreven.

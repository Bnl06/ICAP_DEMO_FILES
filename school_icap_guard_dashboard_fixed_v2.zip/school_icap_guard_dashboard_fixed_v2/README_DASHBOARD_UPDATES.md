# School ICAP Guard dashboard update

Deze build corrigeert de punten uit de feedback en behoudt de bestaande ICAP/backendlogica zoveel mogelijk.

## Belangrijkste wijzigingen

- `school_icap_guard.py` aangepast.
- DLP scant opnieuw alleen HTTP `POST` request-body in `REQMOD`.
  - Geen DLP-block meer omdat gevoelige tekst op een webpagina staat.
  - Geen DLP-scan op `RESPMOD`, URL of headers.
- Sidebar kan inklappen en onthoudt de keuze in `localStorage`.
- Layout-overflow gefixt zodat de pagina niet horizontaal hoort te scrollen.
- Logs worden na service-restart opnieuw ingeladen uit `events.jsonl`.
- Allowed domains krijgen prioriteit op normale/harde blacklistmatches zoals UT1-imports.
  - Daarna kunnen malware/DLP/content checks nog steeds blokkeren, tenzij `allow_domains_bypass_content` actief is.
- Weighted phrases staan standaard uit.
- Nieuwe installs maken geen standaard Engelse/Nederlandse phraselists meer aan.
- Categorieën blijven wel bestaan, zodat je later eigen phraselists kunt toevoegen.
- Nieuwe installs hebben geen `student`/`teacher` starter policies/users meer.
- DLP default rules zijn niet meer beperkt tot `student`/`teacher`, zodat NetBird-groepen ook kunnen werken.
- Policy-instellingen voor bypass/fail-open zijn zichtbaar in het dashboard:
  - `allow_domains_bypass_content`
  - per-policy malware aan/uit
  - per-policy DLP aan/uit
  - ClamAV `fail_open`

## Aangepaste bestanden

```text
icap_guard_single_file/school_icap_guard.py
icap_guard_single_file/disable_default_phrases_and_groups.py
netbird_icap_auto_sync_etc_schoolicap/school_icap_guard.py
netbird_icap_auto_sync_etc_schoolicap/disable_default_phrases_and_groups.py
```

De NetBird sync-file zelf is niet aangepast:

```text
netbird_icap_auto_sync_etc_schoolicap/sync_netbird_users.py
```

## Deploy van alleen dashboard

```bash
cd /pad/naar/uitgepakte/zip/icap_guard_single_file

sudo cp /opt/school-icap-guard/school_icap_guard.py /opt/school-icap-guard/school_icap_guard.py.backup.$(date +%F-%H%M%S)

sudo install -o root -g root -m 0755 school_icap_guard.py /opt/school-icap-guard/school_icap_guard.py

python3 -m py_compile /opt/school-icap-guard/school_icap_guard.py
sudo systemctl restart school-icap-guard
sudo journalctl -u school-icap-guard -n 100 --no-pager
```

## Oude default phrases/student/teacher opruimen

Omdat je bestaande `config.json`, `users.json` en phrase-mappen op de server bewaard blijven, verwijdert een nieuwe `.py` niet automatisch oude data. Gebruik dit script eenmalig als je alle oude default phrases en startergroepen wilt uitschakelen.

```bash
cd /pad/naar/uitgepakte/zip/icap_guard_single_file
sudo python3 disable_default_phrases_and_groups.py --config-dir /etc/school-icap-guard
sudo systemctl restart school-icap-guard
```

Wat het script doet:

- maakt backups van `config.json`, `users.json` en `dlp_rules.json`
- zet `weighted_phrases_enabled=false`
- leegt alle `phrase_thresholds`
- verwijdert `phrase_total_threshold`
- verwijdert oude starter policies/users `student` en `teacher`
- haalt oude `student`/`teacher` restricties uit starter DLP rules
- hernoemt bestaande `.weightedphraselist` en `.phraselist` bestanden naar `.disabled`

Het script verwijdert phraselist-bestanden niet definitief. Terugzetten kan door `.disabled` opnieuw van de bestandsnaam te halen.

Wil je `student` en `teacher` toch behouden, gebruik:

```bash
sudo python3 disable_default_phrases_and_groups.py --config-dir /etc/school-icap-guard --keep-starter-groups
```

## Testen

Getest met:

```bash
python3 -m py_compile school_icap_guard.py
python3 school_icap_guard.py --config-dir /tmp/school-icap-guard-test --init
python3 school_icap_guard.py --config-dir /tmp/school-icap-guard-test --check
python3 -m py_compile disable_default_phrases_and_groups.py
```

Extra gecontroleerd:

- `RESPMOD` met DLP-achtige tekst blijft allowed.
- `REQMOD GET` met DLP-achtige tekst blijft allowed.
- `REQMOD POST` met DLP-achtige body kan nog wel blokkeren.
- Logs uit `events.jsonl` worden na herstart opnieuw zichtbaar.

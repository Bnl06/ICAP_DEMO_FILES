#!/usr/bin/env python3
"""
Sync NetBird users/peers/groups to School ICAP Guard users.json.

What it does:
- Reads NetBird users, peers and groups through the NetBird API.
- Creates / updates users.json with ip_map: NetBird IP -> user -> groups.
- Creates missing ICAP policies in config.json by copying ICAP_POLICY_TEMPLATE
  when configured, otherwise common_policy.
- Keeps existing entra_object_map.

Required environment variables:
- NETBIRD_TOKEN
Optional:
- NETBIRD_API=https://api.netbird.io
- ICAP_CONFIG_DIR=/etc/school-icap-guard
- ICAP_AUTO_CREATE_POLICIES=1
- ICAP_POLICY_TEMPLATE=<existing-policy-name>
- ICAP_FALLBACK_GROUP=netbird_unassigned
"""

from __future__ import annotations

import copy
import json
import os
import pathlib
import re
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

NETBIRD_API = os.environ.get("NETBIRD_API", "https://netbird.secure1e.org").rstrip("/")
NETBIRD_TOKEN = os.environ.get("NETBIRD_TOKEN", "").strip()
CONFIG_DIR = pathlib.Path(os.environ.get("ICAP_CONFIG_DIR", "/etc/school-icap-guard"))
USERS_JSON = CONFIG_DIR / "users.json"
CONFIG_JSON = CONFIG_DIR / "config.json"
AUTO_CREATE_POLICIES = os.environ.get("ICAP_AUTO_CREATE_POLICIES", "1").lower() in {"1", "true", "yes", "on"}
POLICY_TEMPLATE = os.environ.get("ICAP_POLICY_TEMPLATE", "").strip()
FALLBACK_GROUP = os.environ.get("ICAP_FALLBACK_GROUP", "netbird_unassigned")

HEADERS = {
    "Accept": "application/json",
    "Authorization": f"Token {NETBIRD_TOKEN}",
}


def fail(message: str, code: int = 1) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(code)


def api_get(path: str):
    if not NETBIRD_TOKEN:
        fail("NETBIRD_TOKEN is empty. Set it in /etc/school-icap-guard-netbird.env or environment.")

    url = NETBIRD_API + path
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw.strip() else []
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        fail(f"NetBird API HTTP {e.code} on {url}:\n{body}")
    except urllib.error.URLError as e:
        fail(f"NetBird API connection error on {url}: {e}")
    except json.JSONDecodeError as e:
        fail(f"NetBird API returned invalid JSON on {url}: {e}")


def backup_file(path: pathlib.Path) -> None:
    if not path.exists():
        return
    backup_dir = path.parent / ".backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    shutil.copy2(path, backup_dir / f"{path.name}.{stamp}.bak")


def atomic_write_json(path: pathlib.Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    backup_file(path)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=True)
            f.write("\n")
        os.replace(tmp, path)
    finally:
        try:
            if os.path.exists(tmp):
                os.unlink(tmp)
        except OSError:
            pass


def read_json(path: pathlib.Path, fallback):
    if not path.exists():
        return fallback
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        fail(f"Invalid JSON in {path}: {e}")


def normalize_group(value) -> str:
    value = str(value or "").strip().lower()
    value = value.replace("@", "_at_")
    value = re.sub(r"[^a-z0-9_-]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return value or "netbird_unassigned"


def normalize_email(value) -> str:
    return str(value or "").strip().lower()


def listify_api_result(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("items", "data", "results"):
            if isinstance(data.get(key), list):
                return data[key]
    return []


def get_nested(obj, *paths):
    for path in paths:
        current = obj
        ok = True
        for key in path.split("."):
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                ok = False
                break
        if ok and current not in (None, ""):
            return current
    return None


def group_names_from_values(values, group_id_to_name) -> list[str]:
    result = []
    for item in values or []:
        name = None
        if isinstance(item, dict):
            name = item.get("name") or item.get("display_name") or group_id_to_name.get(item.get("id"))
        else:
            name = group_id_to_name.get(item) or item
        if name:
            result.append(normalize_group(name))
    return result


def main() -> int:
    users_api = listify_api_result(api_get("/api/users"))
    peers_api = listify_api_result(api_get("/api/peers"))
    groups_api = listify_api_result(api_get("/api/groups"))

    group_id_to_name = {}
    for group in groups_api:
        if not isinstance(group, dict):
            continue
        gid = group.get("id")
        name = group.get("name") or group.get("display_name")
        if gid and name:
            group_id_to_name[gid] = name

    user_id_to_user = {}
    for user in users_api:
        if not isinstance(user, dict):
            continue
        uid = user.get("id")
        email = normalize_email(user.get("email"))
        if not uid or not email:
            continue
        auto_groups = group_names_from_values(user.get("auto_groups", []), group_id_to_name)
        user_id_to_user[uid] = {
            "email": email,
            "name": user.get("name", ""),
            "role": user.get("role", ""),
            "auto_groups": auto_groups,
            "raw_auto_group_ids": user.get("auto_groups", []),
        }

    old_users = read_json(USERS_JSON, {"users": {}, "ip_map": {}, "entra_object_map": {}})
    output = {
        "users": {},
        "ip_map": {},
        "entra_object_map": old_users.get("entra_object_map", {}),
        "meta": {
            "generated_by": "sync_netbird_users.py",
            "netbird_api": NETBIRD_API,
            "synced_at_unix": int(time.time()),
        },
    }

    all_groups_seen = set()
    skipped_peers = 0

    for peer in peers_api:
        if not isinstance(peer, dict):
            continue

        ip = get_nested(peer, "ip", "address", "netbird_ip", "netbirdIp")
        peer_id = peer.get("id")
        hostname = peer.get("name") or peer.get("hostname") or peer.get("dns_label") or ""
        user_id = get_nested(peer, "user_id", "userId", "user.id")
        user_obj = user_id_to_user.get(user_id)

        if not ip or not user_obj:
            skipped_peers += 1
            continue

        email = user_obj["email"]
        peer_groups = []
        peer_groups += group_names_from_values(peer.get("groups", []), group_id_to_name)
        peer_groups += user_obj.get("auto_groups", [])

        role = normalize_group(user_obj.get("role", ""))
        if role and role not in {"unknown", "none"}:
            peer_groups.append(role)

        if not peer_groups:
            peer_groups = [normalize_group(FALLBACK_GROUP)]

        peer_groups = sorted(set(peer_groups))
        all_groups_seen.update(peer_groups)

        output["users"].setdefault(email, {
            "groups": [],
            "netbird_user_id": user_id,
            "netbird_peer_ids": [],
            "netbird_hostnames": [],
        })
        output["users"][email]["groups"] = sorted(set(output["users"][email]["groups"] + peer_groups))
        if peer_id:
            output["users"][email]["netbird_peer_ids"].append(peer_id)
        if hostname:
            output["users"][email]["netbird_hostnames"].append(hostname)

        output["ip_map"][str(ip)] = {
            "user": email,
            "groups": peer_groups,
        }

    for data in output["users"].values():
        data["groups"] = sorted(set(data.get("groups", [])))
        data["netbird_peer_ids"] = sorted(set(data.get("netbird_peer_ids", [])))
        data["netbird_hostnames"] = sorted(set(data.get("netbird_hostnames", [])))

    atomic_write_json(USERS_JSON, output)

    created_policies = []
    if AUTO_CREATE_POLICIES:
        config = read_json(CONFIG_JSON, {})
        policies = config.setdefault("policies", {})
        template = policies.get(POLICY_TEMPLATE) if POLICY_TEMPLATE else None
        if template is None:
            template = config.get("common_policy", {})
        for group in sorted(all_groups_seen):
            if group not in policies:
                policies[group] = copy.deepcopy(template)
                created_policies.append(group)
        if created_policies:
            atomic_write_json(CONFIG_JSON, config)

    print(f"OK: NetBird users read: {len(users_api)}")
    print(f"OK: NetBird peers read: {len(peers_api)}")
    print(f"OK: synced users: {len(output['users'])}")
    print(f"OK: synced IP mappings: {len(output['ip_map'])}")
    print(f"OK: skipped peers without IP/user: {skipped_peers}")
    print(f"OK: seen groups: {', '.join(sorted(all_groups_seen)) if all_groups_seen else 'none'}")
    if created_policies:
        print(f"OK: created ICAP policies: {', '.join(created_policies)}")
    print(f"OK: wrote {USERS_JSON}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
